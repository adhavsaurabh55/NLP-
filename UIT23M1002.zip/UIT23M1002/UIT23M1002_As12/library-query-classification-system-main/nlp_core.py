"""NLP pipeline: preprocessing -> TF-IDF -> SVM / Naive Bayes -> category-wise BM25 ranking.

Hybrid step: the ML class probabilities are blended with BM25 'evidence' from the whole catalog,
so queries containing words never seen in training (e.g. 'backend') can still be routed correctly.
"""
import re
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, classification_report
from rank_bm25 import BM25Okapi
from data import CATALOG, QUERIES

import nltk
from nltk.stem import PorterStemmer, WordNetLemmatizer

def _ensure(pkg, path):
    try: nltk.data.find(path)
    except LookupError: nltk.download(pkg, quiet=True)
_ensure("stopwords", "corpora/stopwords"); _ensure("wordnet", "corpora/wordnet")
from nltk.corpus import stopwords
STOP = set(stopwords.words("english"))
STEM, LEM = PorterStemmer(), WordNetLemmatizer()

# Small synonym map (query expansion) so different wording still matches catalog terms.
SYNONYMS = {
 "warming": ["climate"], "temperature": ["climate"], "harvest": ["crop", "yield"],
 "farm": ["agriculture", "crop"], "food": ["agriculture"], "medicine": ["drug"],
 "illness": ["disease"], "sick": ["disease"], "stock": ["share"], "company": ["business"],
 "computer": ["machine"], "learns": ["learning"], "learn": ["learning"],
 "backend": ["server", "database", "api"], "frontend": ["web", "html", "javascript"],
 "fullstack": ["web", "backend", "frontend"], "coder": ["programming"], "developer": ["programming"],
 "coding": ["programming"], "app": ["application"], "website": ["web"],
}
LOW_CONF = 0.45   # below this the app warns the user and shows the runner-up category

def tokenize(text):
    return re.findall(r"[a-z]+", text.lower())

def preprocess(text, expand=False):
    toks = [t for t in tokenize(text) if t not in STOP and len(t) > 1]
    toks = [LEM.lemmatize(t) for t in toks]
    if expand:
        toks += [LEM.lemmatize(s) for t in toks for s in SYNONYMS.get(t, [])]
    return [STEM.stem(t) for t in toks]

def prep_str(text):
    return " ".join(preprocess(text))

def _probs(model, vec, text):
    """Class probabilities for one query (softmax of SVM margins / NB posterior). {} if all words unseen."""
    v = vec.transform([prep_str(text)])
    if v.nnz == 0: return {}
    if isinstance(model, MultinomialNB):
        p = model.predict_proba(v)[0]
    else:
        d = model.decision_function(v)[0]; e = np.exp(d - d.max()); p = e / e.sum()
    return dict(zip(model.classes_, p))

class LibrarySystem:
    def __init__(self, seed=42):
        X, y = [], []
        for cat, qs in QUERIES.items():
            for q in qs: X.append(q); y.append(cat)
        self.Xtr, self.Xte, self.ytr, self.yte = train_test_split(
            X, y, test_size=0.25, stratify=y, random_state=seed)
        # Catalog titles/keywords are labelled text too: extra training data
        self.cat_texts = [f"{r[0]} {r[3]}" for r in CATALOG]
        self.cat_labels = [r[2] for r in CATALOG]

        def build(texts, labels):
            vec = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True)
            Xm = vec.fit_transform([prep_str(t) for t in texts])
            return vec, {"SVM": LinearSVC(random_state=seed).fit(Xm, labels),
                         "Naive Bayes": MultinomialNB(alpha=0.5).fit(Xm, labels)}
        # (1) train-only models -> honest evaluation on held-out queries
        self.vec, self.models = build(self.Xtr + self.cat_texts, self.ytr + self.cat_labels)
        # (2) deployment models trained on every labelled query
        self.final_vec, self.final = build(self.Xtr + self.Xte + self.cat_texts,
                                           self.ytr + self.yte + self.cat_labels)
        # BM25 indexes: one per category (retrieval) + one global (category evidence)
        self.by_cat = {}
        for rec in CATALOG: self.by_cat.setdefault(rec[2], []).append(rec)
        doc = lambda r: preprocess(f"{r[0]} {r[3]}")
        self.bm25 = {c: BM25Okapi([doc(r) for r in recs]) for c, recs in self.by_cat.items()}
        self.bm25_all = BM25Okapi([doc(r) for r in CATALOG])

    # ---------- category evidence from BM25 ----------
    def _evidence(self, query):
        q = preprocess(query, expand=True)
        if not q: return {}
        best = {}
        for rec, s in zip(CATALOG, self.bm25_all.get_scores(q)):
            best[rec[2]] = max(best.get(rec[2], 0.0), float(max(s, 0.0)))
        tot = sum(best.values())
        return {c: v / tot for c, v in best.items()} if tot > 0 else {}

    @staticmethod
    def _blend(probs, ev, w=0.5):
        if not probs: return ev
        if not ev: return probs
        return {c: (1 - w) * probs.get(c, 0) + w * ev.get(c, 0) for c in set(probs) | set(ev)}

    # ---------- evaluation (held-out queries) ----------
    def evaluate(self):
        out = {}
        def metrics(pred):
            pr, rc, f1, _ = precision_recall_fscore_support(self.yte, pred, average="weighted", zero_division=0)
            return dict(accuracy=accuracy_score(self.yte, pred), precision=pr, recall=rc, f1=f1,
                        report=classification_report(self.yte, pred, zero_division=0))
        for name, m in self.models.items():
            pred = []
            for q in self.Xte:
                p = _probs(m, self.vec, q)
                pred.append(max(p, key=p.get) if p else "?")
            out[name] = metrics(pred)
        for name, m in self.models.items():
            pred = []
            for q in self.Xte:
                b = self._blend(_probs(m, self.vec, q), self._evidence(q))
                pred.append(max(b, key=b.get) if b else "?")
            out[f"{name} + BM25 (hybrid)"] = metrics(pred)
        return out

    # ---------- inference ----------
    def classify(self, query, model="SVM"):
        b = self._blend(_probs(self.final[model], self.final_vec, query), self._evidence(query))
        if not b: return None, {}
        t = sum(b.values()); b = {c: v / t for c, v in b.items()}
        return max(b, key=b.get), b

    def rank_in(self, cat, query, top_k=5):
        q = preprocess(query, expand=True)
        scores = self.bm25[cat].get_scores(q)
        ranked = sorted(zip(self.by_cat[cat], scores), key=lambda x: -x[1])[:top_k]
        return [(r, float(s)) for r, s in ranked]

    def search(self, query, model="SVM", top_k=5):
        cat, probs = self.classify(query, model)
        if cat is None: return None, probs, []
        return cat, probs, self.rank_in(cat, query, top_k)

if __name__ == "__main__":
    s = LibrarySystem()
    for n, r in s.evaluate().items():
        print(f"== {n}: acc={r['accuracy']:.3f} P={r['precision']:.3f} R={r['recall']:.3f} F1={r['f1']:.3f}")
    for q in ["impact of global warming on food production", "machine that learns from data",
              "backend development", "web development", "business development strategy",
              "economic development", "gibberish zzz"]:
        c, p, res = s.search(q)
        print(f"\nQ: {q} -> {c} ({p[c]:.0%})" if c else f"\nQ: {q} -> None")
        for (t, a, cat, d), sc in res[:3]: print(f"   {sc:.2f}  {t} ({a})")
